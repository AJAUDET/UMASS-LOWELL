// Copyright (c) 2026 AJ Audet

int main() {
    return 0;
}
