// Copyright (c) 2026 AJ Audet

#include "SpriteSheet.hpp"

int main() {
    return 0;
}
